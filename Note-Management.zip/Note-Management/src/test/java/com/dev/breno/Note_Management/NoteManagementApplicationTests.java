package com.dev.breno.Note_Management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NoteManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
